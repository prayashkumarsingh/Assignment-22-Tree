/**
 * 
 */
/**
 * @author Prayash
 *
 */
module Question1 {
}